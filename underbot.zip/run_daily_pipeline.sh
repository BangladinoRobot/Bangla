#!/bin/bash

# Vai nella cartella del progetto
cd /home/pi/underbot || exit 1

# Attiva il virtualenv
source venv/bin/activate

# Lancia in sequenza gli script Python
python3 screen_league_fixtures.py
python3 run_stats_on_league_fixtures.py
python3 odds_layer_theoddsapi.py
