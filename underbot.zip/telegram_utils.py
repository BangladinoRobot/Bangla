import time
import requests
from config import TELEGRAM_TOKEN, CHAT_ID

TELEGRAM_API_URL = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"


def send_telegram_message(text, max_retries=3, delay_seconds=5):
    """
    Invia un messaggio di testo al canale/chat Telegram configurato
    in CHAT_ID, usando Markdown per grassetto/corsivo/monospace,
    con qualche tentativo di retry se la rete fa i capricci.
    """
    data = {
        "chat_id": CHAT_ID,
        "text": text,
        "parse_mode": "Markdown",
    }

    for attempt in range(1, max_retries + 1):
        try:
            resp = requests.post(TELEGRAM_API_URL, data=data, timeout=10)
            if resp.status_code == 200:
                return
            else:
                print(
                    f"Errore nell'invio del messaggio Telegram "
                    f"(tentativo {attempt}/{max_retries}):",
                    resp.status_code,
                    resp.text,
                )
        except Exception as e:
            print(
                f"Eccezione nell'invio del messaggio Telegram "
                f"(tentativo {attempt}/{max_retries}): {e}"
            )

        if attempt < max_retries:
            time.sleep(delay_seconds)

    print("Invio messaggio Telegram fallito dopo tutti i tentativi.")
