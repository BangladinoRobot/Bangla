import requests
from datetime import date
from config import API_FOOTBALL_KEY

BASE_URL = "https://v3.football.api-sports.io"

def main():
    # Puoi cambiare questa data se vuoi provarne un'altra
    d = date.today().strftime("%Y-%m-%d")
    print(f"Controllo le fixture API-Football per il giorno: {d}")

    url = f"{BASE_URL}/fixtures"
    headers = {
        "x-apisports-key": API_FOOTBALL_KEY
    }
    params = {
        "date": d
    }

    resp = requests.get(url, headers=headers, params=params)
    print("Status code:", resp.status_code)
    if resp.status_code != 200:
        print(resp.text)
        return

    data = resp.json()
    print("Risultati totali (tutte le competizioni):", data.get("results"))

    for i, fx in enumerate(data.get("response", [])[:50], start=1):
        fixture = fx.get("fixture", {})
        league  = fx.get("league", {})
        teams   = fx.get("teams", {})

        fid   = fixture.get("id")
        fdate = fixture.get("date")
        lname = league.get("name")
        lcountry = league.get("country")
        ltype = league.get("type")  # QUI vediamo se è 'League', 'Cup', etc.

        hname = teams.get("home", {}).get("name")
        aname = teams.get("away", {}).get("name")

        print(f"{i:02d}) id={fid} | {fdate} | {lcountry} - {lname} (type={ltype}) | {hname} vs {aname}")

if __name__ == "__main__":
    main()
