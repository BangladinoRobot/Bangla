import os
import json
import requests
from config import API_FOOTBALL_KEY
from datetime import datetime, timedelta

def prune_registry(registry, keep_days=180):
    """
    Rimuove dal registro le partite troppo vecchie.
    Per default tiene solo le partite con fixture_date (o checked_at) negli ultimi 180 giorni.
    """
    cutoff = datetime.utcnow() - timedelta(days=keep_days)
    new_registry = {}
    removed = 0

    for key, info in registry.items():
        date_str = info.get("fixture_date") or info.get("checked_at")
        if not date_str:
            # se non abbiamo data, per sicurezza teniamo l'entry
            new_registry[key] = info
            continue

        try:
            s = date_str
            if s.endswith("Z"):
                s = s[:-1] + "+00:00"
            dt = datetime.fromisoformat(s)
        except Exception:
            # se il parse fallisce, teniamo l'entry
            new_registry[key] = info
            continue

        if dt < cutoff:
            removed += 1
        else:
            new_registry[key] = info

    print(f"Pulizia registro: rimossi {removed} elementi vecchi, rimasti {len(new_registry)}.")
    return new_registry

BASE_URL = "https://v3.football.api-sports.io"
headers = {
    "x-apisports-key": API_FOOTBALL_KEY
}

REGISTRY_FILE = "stats_checked.json"


# ---------- GESTIONE REGISTRO ----------

def load_registry():
    """Carica il registro da file, oppure restituisce un dizionario vuoto se non esiste."""
    if not os.path.exists(REGISTRY_FILE):
        return {}
    try:
        with open(REGISTRY_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        # Se il file è corrotto o vuoto, ripartiamo da zero
        return {}


def save_registry(registry):
    """Salva il registro su file."""
    with open(REGISTRY_FILE, "w", encoding="utf-8") as f:
        json.dump(registry, f, ensure_ascii=False, indent=2)


# ---------- FUNZIONI API-FOOTBALL (come nello script singolo) ----------

def get_fixture(fixture_id):
    url = f"{BASE_URL}/fixtures"
    params = {"id": fixture_id}
    resp = requests.get(url, headers=headers, params=params)
    resp.raise_for_status()
    data = resp.json()
    if not data.get("response"):
        raise ValueError(f"Nessuna fixture trovata per id {fixture_id}")
    return data["response"][0]


def get_last_matches(team_id, n=7):
    """
    Restituisce le ultime n partite della squadra
    (campionato + coppe + amichevoli, tutte le competizioni).
    """
    url = f"{BASE_URL}/fixtures"
    params = {
        "team": team_id,
        "last": n
    }
    resp = requests.get(url, headers=headers, params=params)
    resp.raise_for_status()
    data = resp.json()
    return data.get("response", [])


def count_00_11(fixtures):
    """Conta quante partite sono finite 0–0 o 1–1."""
    count = 0
    for f in fixtures:
        goals_home = f["goals"]["home"]
        goals_away = f["goals"]["away"]
        if goals_home is None or goals_away is None:
            continue
        if (goals_home == 0 and goals_away == 0) or (goals_home == 1 and goals_away == 1):
            count += 1
    return count


# ---------- ANALISI DI UNA SINGOLA PARTITA CON REGISTRO ----------

def analyze_fixture_with_registry(fixture_id, registry):
    """
    Analizza una fixture:
    - se è già nel registro, la salta
    - altrimenti calcola lo storico 7x7 e salva il risultato nel registro
    """
    key = str(fixture_id)
    if key in registry:
        info = registry[key]
        print(f"⚪ Fixture {fixture_id} già analizzata: "
              f"{info['home_name']} vs {info['away_name']} "
              f"(totale {info['total_00_11']} su 14, passa={info['passes_rule']})")
        return registry

    print(f"\n🔍 Analizzo fixture id {fixture_id}...")

    fixture = get_fixture(fixture_id)
    home_team = fixture["teams"]["home"]
    away_team = fixture["teams"]["away"]

    home_id = home_team["id"]
    away_id = away_team["id"]
    home_name = home_team["name"]
    away_name = away_team["name"]

    print(f"Partita: {home_name} vs {away_name}")
    print(f"Home team id: {home_id}, Away team id: {away_id}")

    # Ultime 7 partite di ciascuna squadra (tutte le competizioni)
    print(f"\nRecupero ultime 7 partite del {home_name}...")
    last_home = get_last_matches(home_id, 7)
    print("Trovate", len(last_home), "partite.")

    print(f"Recupero ultime 7 partite del {away_name}...")
    last_away = get_last_matches(away_id, 7)
    print("Trovate", len(last_away), "partite.")

    home_00_11 = count_00_11(last_home)
    away_00_11 = count_00_11(last_away)
    total_00_11 = home_00_11 + away_00_11
    passes = total_00_11 >= 7

    print(f"\n{home_name}: {home_00_11} partite 0–0 o 1–1 su 7")
    print(f"{away_name}: {away_00_11} partite 0–0 o 1–1 su 7")
    print(f"Totale: {total_00_11} su 14")

    if passes:
        print("✅ La partita PASSA la regola 7 su 14 (0–0 / 1–1).")
    else:
        print("❌ La partita NON passa la regola 7 su 14.")

    # Salviamo nel registro
    # Salviamo nel registro (con anche la data della partita e quando l'abbiamo analizzata)
    fixture_date = fixture["fixture"]["date"]  # data della partita dalle API

    registry[key] = {
        "fixture_id": fixture_id,
        "home_id": home_id,
        "away_id": away_id,
        "home_name": home_name,
        "away_name": away_name,
        "home_00_11": home_00_11,
        "away_00_11": away_00_11,
        "total_00_11": total_00_11,
        "passes_rule": passes,
        "fixture_date": fixture_date,                 # es. "2025-11-20T19:45:00+00:00"
        "checked_at": datetime.utcnow().isoformat(),  # quando abbiamo fatto l'analisi
    }

    return registry

def main():
    # 1) carichiamo il registro
    registry = load_registry()
    print(f"Registro iniziale: {len(registry)} partite già analizzate.")

    # 2) ELENCO DI TEST: qui mettiamo qualche fixture_id a mano.
    # Per ora puoi riusare uno di quelli che hai usato con test_fixtures, es. 1456961.
    fixture_ids_to_check = [
        1456961,  # metti qui un id a piacere
        1457119,  # e un altro id, giusto per vedere l'effetto registro
    ]

    for fid in fixture_ids_to_check:
        registry = analyze_fixture_with_registry(fid, registry)

    # 3) salviamo il registro aggiornato
    save_registry(registry)
    print(f"\nRegistro finale: {len(registry)} partite analizzate salvate in {REGISTRY_FILE}.")


if __name__ == "__main__":
    main()
