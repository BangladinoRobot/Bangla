import requests
from datetime import date, timedelta
from config import API_FOOTBALL_KEY

BASE_URL = "https://v3.football.api-sports.io"
headers = {
    "x-apisports-key": API_FOOTBALL_KEY
}

# Guardiamo solo oggi + prossimi 3 giorni (4 giorni in totale)
MAX_DAYS_AHEAD = 3

# Se per 3 giorni di fila non ci sono campionati, ci fermiamo
STOP_IF_NO_LEAGUES_DAYS = 3

# Paesi considerati "Sud America" per la priorità
SOUTH_AMERICAN_COUNTRIES = {
    "Argentina",
    "Brazil",
    "Chile",
    "Colombia",
    "Ecuador",
    "Peru",
    "Uruguay",
    "Paraguay",
    "Bolivia",
    "Venezuela",
}

def priority_key(fixture):
    """Restituisce una tupla (priorità, data, paese, lega) per ordinare le partite."""
    league = fixture["league"]
    country = league.get("country") or ""
    fixture_date = fixture["fixture"]["date"]  # stringa ISO
    league_name = league.get("name") or ""

    # Priorità 1: campionati sudamericani
    if country in SOUTH_AMERICAN_COUNTRIES:
        pri = 1
    # Priorità 2: Pakistan
    elif country == "Pakistan":
        pri = 2
    # Priorità 3: Israele
    elif country == "Israel":
        pri = 3
    # Priorità 4: tutto il resto
    else:
        pri = 4

    return (pri, fixture_date, country, league_name)

def main():
    today = date.today()
    all_league_fixtures = []
    seen_ids = set()

    no_league_days_in_a_row = 0

    for offset in range(MAX_DAYS_AHEAD + 1):
        d = today + timedelta(days=offset)
        d_str = d.isoformat()
        print(f"\n=== Giorno {d_str} ===")

        url = f"{BASE_URL}/fixtures"
        params = {"date": d_str}
        resp = requests.get(url, headers=headers, params=params)
        print("Status code fixtures:", resp.status_code)

        data = resp.json()
        day_fixtures = data.get("response", [])

        league_fixtures = [
            f for f in day_fixtures
            if f["league"].get("type") == "League"
        ]

        print("Partite totali (tutte le competizioni):", len(day_fixtures))
        print("Partite di campionato (League):", len(league_fixtures))

        if len(league_fixtures) == 0:
            no_league_days_in_a_row += 1
            if no_league_days_in_a_row >= STOP_IF_NO_LEAGUES_DAYS:
                print(f"\nNessun campionato per {STOP_IF_NO_LEAGUES_DAYS} giorni consecutivi. Mi fermo qui.")
                break
        else:
            no_league_days_in_a_row = 0

        for f in league_fixtures:
            fid = f["fixture"]["id"]
            if fid in seen_ids:
                continue
            seen_ids.add(fid)
            all_league_fixtures.append(f)

    print("\n==============================")
    print("Totale partite di campionato trovate nei prossimi giorni:", len(all_league_fixtures))

    # Ordiniamo per priorità (Sud America -> Pakistan -> Israele -> altri),
    # poi per data, paese, lega
    all_league_fixtures_sorted = sorted(all_league_fixtures, key=priority_key)

    print("\n==============================")
    print("Totale partite di campionato trovate nei prossimi giorni:", len(all_league_fixtures))

    # Ordiniamo per priorità (Sud America -> Pakistan -> Israele -> altri),
    # poi per data, paese, lega
    all_league_fixtures_sorted = sorted(all_league_fixtures, key=priority_key)

    print("\nElenco partite di campionato ordinate per priorità:")
    for f in all_league_fixtures_sorted:
        fixture_id = f["fixture"]["id"]
        country = f["league"]["country"]
        league_name = f["league"]["name"]
        home = f["teams"]["home"]["name"]
        away = f["teams"]["away"]["name"]
        match_date = f["fixture"]["date"]
        print(f"{match_date} | {fixture_id} | {country} - {league_name}: {home} vs {away}")

    # Salviamo le partite di campionato in un file JSON, per usarle dopo
    fixtures_for_json = []
    for f in all_league_fixtures_sorted:
        fixtures_for_json.append({
            "fixture_id": f["fixture"]["id"],
            "date": f["fixture"]["date"],
            "country": f["league"]["country"],
            "league_name": f["league"]["name"],
            "home_name": f["teams"]["home"]["name"],
            "away_name": f["teams"]["away"]["name"],
            "home_id": f["teams"]["home"]["id"],
            "away_id": f["teams"]["away"]["id"],
        })

    import json
    with open("league_fixtures.json", "w", encoding="utf-8") as jf:
        json.dump(fixtures_for_json, jf, ensure_ascii=False, indent=2)

    print(f"\nSalvate {len(fixtures_for_json)} partite di campionato in league_fixtures.json")


if __name__ == "__main__":
    main()
